(function(i) {
    var value1 = parseInt(i);
    return +Math.floor((value1 * 100) / 255);
})(input)