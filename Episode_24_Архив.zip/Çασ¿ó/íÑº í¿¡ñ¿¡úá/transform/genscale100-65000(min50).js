(function(i) {
    var value = parseInt(i);
    return +Math.floor(50 + (value * 64950) / 100);
})(input)