(function(i) {
    var value = parseInt(i);
    return +Math.floor((value * 255) / 100);
})(input)