(function(i) {
    var value = parseInt(i);
    return +Math.floor((value * 65000) / 100);
})(input)